/* 
 * 20190311.001
 * TFT 240x400
 *
 * File: main.h
 * Processor: PIC18F2455
 * Author: wizlab.it
 */

#ifndef MAIN_H
#define	MAIN_H

#include "commons.h"

void loop(void);

#endif